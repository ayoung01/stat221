source('ps3_YoungGentili_2_functions.R')

est = get.data.all.2b(1e4, alpha=1)
plot.risk.all(est)